import { API_BASE } from './api';
export type Prod = { gtin: string; name?: string; coo?: string };
let cache: Record<string, Prod> | null = null;
async function loadProducts(): Promise<Record<string, Prod>>{
  if (cache) return cache;
  const res = await fetch(API_BASE + '/bundles/demo/products.json');
  const arr = await res.json();
  cache = {};
  for (const p of arr) cache![p.gtin] = p;
  return cache!;
}

export async function decide(gtin: string){
  const db = await loadProducts();
  const p = db[gtin];
  if(!p) return { level: 'LOW', reasons: ['Unknown item'], coo: null, name: 'Unknown' };
  // Simple rule: if COO is in demo-sanctioned list, flag HIGH
  const sancRes = await fetch(API_BASE + '/bundles/demo/sanctions_min.json');
  const sanc = await sancRes.json();
  const chips = (sanc.jurisdictions[p.coo] || []) as string[];
  if (chips.length) return { level: 'HIGH', reasons: ['Origin under sanctions'], coo: p.coo, name: p.name, chips };
  return { level: 'LOW', reasons: ['Matches your preferences'], coo: p.coo, name: p.name, chips: [] };
}

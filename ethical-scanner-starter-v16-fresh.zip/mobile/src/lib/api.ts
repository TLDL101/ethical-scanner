import { Platform } from 'react-native';
const DEV_BASE = Platform.select({ android: 'http://10.0.2.2:8000', ios: 'http://localhost:8000', default: 'http://localhost:8000' });
export const API_BASE = (__DEV__ ? DEV_BASE! : (process.env.PROD_API_BASE || DEV_BASE!));
export const API_V1 = API_BASE + '/v1';

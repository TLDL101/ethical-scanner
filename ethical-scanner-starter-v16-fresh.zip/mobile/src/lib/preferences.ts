import AsyncStorage from '@react-native-async-storage/async-storage';
export type Preferences = { avoidCountries?: string[]; preferCertified?: boolean };
export async function getPrefs(): Promise<Preferences>{ try{ const raw = await AsyncStorage.getItem('prefs'); return raw? JSON.parse(raw): {}; } catch { return {}; } }
export async function setPrefs(p: Preferences){ await AsyncStorage.setItem('prefs', JSON.stringify(p)); }

import AsyncStorage from '@react-native-async-storage/async-storage';
export async function isSimpleMode(){ const raw = await AsyncStorage.getItem('simple_mode'); if(raw===null){ await AsyncStorage.setItem('simple_mode','true'); return true;} return raw==='true'; }
export async function isFirstRun(){ const raw = await AsyncStorage.getItem('first_run_done'); return raw!=='1'; }
export async function markFirstRunDone(){ await AsyncStorage.setItem('first_run_done','1'); }

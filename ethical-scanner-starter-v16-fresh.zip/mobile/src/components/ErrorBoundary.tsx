import React from 'react';
import { View, Text } from 'react-native';
export default class ErrorBoundary extends React.Component<any, {hasError:boolean}>{
  constructor(p:any){ super(p); this.state={hasError:false};}
  static getDerivedStateFromError(e:any){ return { hasError: true };}
  render(){ if(this.state.hasError){ return <View style={{flex:1,justifyContent:'center',alignItems:'center',backgroundColor:'#0b0b0c'}}><Text style={{color:'white'}}>Something went wrong</Text></View>;} return this.props.children; }
}

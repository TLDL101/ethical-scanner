import React from 'react';
import { View, Text, Modal, TouchableOpacity } from 'react-native';
export function LegendModal({ visible, onClose }:{visible:boolean; onClose:()=>void}){
  return (<Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
    <View style={{flex:1,backgroundColor:'rgba(0,0,0,0.8)',justifyContent:'center',padding:16}}>
      <View style={{backgroundColor:'#0b0b0c',padding:16,borderRadius:12}}>
        <Text style={{color:'white',fontWeight:'800',fontSize:18,marginBottom:8}}>Badges & meaning</Text>
        <Text style={{color:'white',marginBottom:6}}>• Sanctions: jurisdictions that sanction this country.</Text>
        <Text style={{color:'white',marginBottom:6}}>• Confidence: how strong the origin signal is.</Text>
        <TouchableOpacity onPress={onClose} style={{backgroundColor:'#111827',padding:10,borderRadius:8,marginTop:12}}><Text style={{color:'white',textAlign:'center'}}>Close</Text></TouchableOpacity>
      </View>
    </View>
  </Modal>);
}

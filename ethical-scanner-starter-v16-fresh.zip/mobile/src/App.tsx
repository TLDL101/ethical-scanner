import React from 'react';
import { SafeAreaView, View, Text, TouchableOpacity } from 'react-native';
import './i18n';
import ScanScreen from './screens/ScanScreen';
import SettingsScreen from './screens/SettingsScreen';
import Onboarding from './screens/Onboarding';
import { isSimpleMode, isFirstRun } from './lib/simple';
import ErrorBoundary from './components/ErrorBoundary';

type Tab = 'scan' | 'settings';

export default function App(){
  const [tab, setTab] = React.useState<Tab>('scan');
  const [simple, setSimple] = React.useState(true);
  const [first, setFirst] = React.useState(true);

  React.useEffect(()=>{ (async ()=>{
    try { setSimple(await isSimpleMode()); setFirst(await isFirstRun()); } catch {}
  })(); }, []);

  return (
    <ErrorBoundary>
    <SafeAreaView style={{ flex:1, backgroundColor:'#0b0b0c' }}>
      <View style={{ flexDirection:'row', justifyContent:'space-around', alignItems:'center', paddingVertical:12, borderBottomWidth:1, borderColor:'#1f2937' }}>
        <TouchableOpacity onPress={()=>setTab('scan')} accessibilityRole='button' accessibilityLabel='scan tab'><Text style={{ color: tab==='scan'? '#4ade80':'white', fontWeight:'700' }}>Scan</Text></TouchableOpacity>
        <TouchableOpacity onPress={()=>setTab('settings')} accessibilityRole='button' accessibilityLabel='settings tab'><Text style={{ color: tab==='settings'? '#4ade80':'white', fontWeight:'700' }}>Settings</Text></TouchableOpacity>
      </View>

      {first ? <Onboarding onDone={()=>setFirst(false)} /> : (tab==='scan' ? <ScanScreen/> : <SettingsScreen/>)}
    </SafeAreaView>
    </ErrorBoundary>
  );
}

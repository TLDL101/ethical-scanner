import React, { useState } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { markFirstRunDone } from '../lib/simple';
import { getPrefs, setPrefs } from '../lib/preferences';

export default function Onboarding({ onDone }:{ onDone: ()=>void }){
  const [avoid, setAvoid] = useState(true);
  const [certs, setCerts] = useState(true);
  const finish = async ()=>{
    const base = await getPrefs();
    await setPrefs({ ...base, avoidCountries: avoid? ['RU','IR','KP','SY','CU','BY'] : (base.avoidCountries||[]), preferCertified: certs });
    await markFirstRunDone();
    onDone();
  };
  return (<View style={{flex:1,backgroundColor:'#0b0b0c',padding:16,paddingTop:48}}>
    <Text style={{color:'white',fontSize:24,fontWeight:'800',marginBottom:8}}>Shop your values</Text>
    <Text style={{color:'white',opacity:0.8,marginBottom:16}}>Two quick choices. Change anytime in Settings.</Text>
    <View style={{backgroundColor:'#111827',padding:16,borderRadius:12,marginBottom:12}}>
      <Text style={{color:'white',fontWeight:'700',marginBottom:6}}>Avoid sanctioned countries</Text>
      <TouchableOpacity onPress={()=>setAvoid(!avoid)} style={{backgroundColor: avoid? '#059669':'#374151',padding:10,borderRadius:8}}><Text style={{color:'white',textAlign:'center'}}>{avoid? 'Enabled':'Disabled'}</Text></TouchableOpacity>
    </View>
    <View style={{backgroundColor:'#111827',padding:16,borderRadius:12,marginBottom:12}}>
      <Text style={{color:'white',fontWeight:'700',marginBottom:6}}>Prefer certified products</Text>
      <TouchableOpacity onPress={()=>setCerts(!certs)} style={{backgroundColor: certs? '#059669':'#374151',padding:10,borderRadius:8}}><Text style={{color:'white',textAlign:'center'}}>{certs? 'Enabled':'Disabled'}</Text></TouchableOpacity>
    </View>
    <TouchableOpacity onPress={finish} style={{backgroundColor:'#2563eb',padding:14,borderRadius:12}}><Text style={{color:'white',textAlign:'center',fontWeight:'700'}}>Start scanning</Text></TouchableOpacity>
  </View>);
}

import React from 'react';
import { View, Text } from 'react-native';
export default function SettingsScreen(){
  return (<View style={{flex:1,backgroundColor:'#0b0b0c',padding:16,paddingTop:48}}>
    <Text style={{color:'white',fontSize:22,fontWeight:'700',marginBottom:8}}>Settings</Text>
    <Text style={{color:'white',opacity:0.8}}>Advanced tools are hidden in this simplified build. You can still paste receipts/links in future versions.</Text>
  </View>);
}

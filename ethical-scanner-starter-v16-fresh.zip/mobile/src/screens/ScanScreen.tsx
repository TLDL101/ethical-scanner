import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import { BarCodeScanner } from 'expo-barcode-scanner';
import { decide } from '../lib/matcher';
import { API_BASE, API_V1 } from '../lib/api';

export default function ScanScreen(){
  const [hasPermission, setHasPermission] = useState<boolean|null>(null);
  const [result, setResult] = useState<any>(null);
  const [evidenceUri, setEvidenceUri] = useState<string|null>(null);

  useEffect(()=>{
    (async ()=>{
      const { status } = await BarCodeScanner.requestPermissionsAsync();
      setHasPermission(status === 'granted');
    })();
  },[]);

  const onScan = async ({ data }: any) => {
    // GTINs vary in length; just forward as-is
    const dec = await decide(data);
    setResult({ gtin: data, ...dec });
  };

  const report = async ()=>{
    if(!result?.gtin) return;
    const body = new FormData();
    body.append('gtin', result.gtin);
    body.append('reason','user_mismatch');
    body.append('notes','');
    body.append('ocr_text','');
    try{
      await fetch(API_V1 + '/reports', { method:'POST', body });
      alert('Thanks — report submitted.');
    }catch(e){ alert('Could not submit.'); }
  };

  if (hasPermission === null) return <View style={{flex:1,backgroundColor:'#0b0b0c'}}/>;
  if (hasPermission === false) return <View style={{flex:1,justifyContent:'center',alignItems:'center',backgroundColor:'#0b0b0c'}}><Text style={{color:'white'}}>Camera permission required</Text></View>;

  return (
    <View style={{ flex: 1, backgroundColor:'#0b0b0c', padding: 16, paddingTop: 48 }}>
      <Text style={{ color: 'white', fontSize: 22, fontWeight: '700', marginBottom: 8 }}>Scan</Text>
      <View style={{ overflow:'hidden', borderRadius: 12, borderWidth: 1, borderColor: '#1f2937', height: 260, marginBottom: 12 }}>
        <BarCodeScanner onBarCodeScanned={result ? undefined : onScan} style={{ width: '100%', height: '100%' }} />
      </View>

      {result ? (
        <View style={{ backgroundColor: '#111827', padding: 12, borderRadius: 12 }}>
          <Text style={{ color: result.level === 'HIGH' ? '#ef4444' : (result.level === 'MEDIUM' ? '#fbbf24' : '#4ade80'), fontWeight: '800', fontSize: 18 }}>
            {result.level === 'HIGH' ? 'Consider avoiding' : (result.level === 'MEDIUM' ? 'Use caution' : 'Good to buy')}
          </Text>
          <Text style={{ color: 'white', opacity: 0.85, marginBottom: 6 }}>{(result.reasons && result.reasons[0]) ? result.reasons[0] : 'Matches your preferences.'}</Text>
          {result.coo ? <Text style={{ color:'white', opacity:0.8 }}>Origin: {result.coo}</Text> : null}
          {result.chips?.length ? <Text style={{ color:'white', opacity:0.8 }}>Sanctions: {result.chips.join(', ')}</Text> : null}

          <TouchableOpacity onPress={report} style={{ marginTop: 8, backgroundColor: '#ef4444', padding: 10, borderRadius: 8 }}><Text style={{ color: 'white', textAlign: 'center' }}>Report a mistake</Text></TouchableOpacity>
          <TouchableOpacity onPress={()=>setResult(null)} style={{ marginTop: 8, backgroundColor: '#374151', padding: 10, borderRadius: 8 }}><Text style={{ color: 'white', textAlign: 'center' }}>Scan another</Text></TouchableOpacity>
        </View>
      ) : (
        <Text style={{ color:'white', opacity:0.8 }}>Point at a barcode.</Text>
      )}
    </View>
  );
}
